<h3 align="center">MindX Web 🥜</h3>

<p align="center">
    <img src="images/preview.png" alt="mindx web">
</p>